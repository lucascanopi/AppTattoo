package com.example.logonrmlocal.apptattoo

class AppTattoo(val tattoo: String, val tipo: String){

}